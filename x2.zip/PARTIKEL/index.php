<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Software Developer">
    <meta name="author" content="Bhavik kalal">
    <link rel="shortcut icon" href="avtar.jpg?1"/>
    <link rel="stylesheet" href="css/style.css?1">
    <title>Bhavik Kalal</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cldup.com/S6Ptkwu_qA.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>

<style>
    svg {
        width: 25px;
    }
</style>

<body class="">
<div id="particles-js"></div>
<div style="height:50px"></div>
<div class="animated bounceInDown site">
    <div class="avatar">
        <a><img src="avtar.jpeg" alt="Avatar" style="border:8px solid white;"/> </a>
    </div>
    <div class="content">
        <a style="font-size: 2.5em!important;font-family: monospace;">
            Bhavik Kalal
        </a>
        <p style="font-size:1em;">There are two ways to write error-free programs; only the third one works.</p>
        <p style="font-size:1.1em;">Software &amp Web Developer ;</p>
        <ul class="social-icons">

            <li><a href="https://instagram.com/iambhavikkalal" target="_blank">
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 551.034 551.034"
                         style="enable-background:new 0 0 551.034 551.034;" xml:space="preserve"><g>
                            <linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="275.517" y1="4.57"
                                            x2="275.517" y2="549.72" gradientTransform="matrix(1 0 0 -1 0 554)">
                                <stop offset="0" style="stop-color:#E09B3D"></stop>
                                <stop offset="0.3" style="stop-color:#C74C4D"></stop>
                                <stop offset="0.6" style="stop-color:#C21975"></stop>
                                <stop offset="1" style="stop-color:#7024C4"></stop>
                            </linearGradient>
                            <path style="fill:url(#SVGID_1_);"
                                  d="M386.878,0H164.156C73.64,0,0,73.64,0,164.156v222.722 c0,90.516,73.64,164.156,164.156,164.156h222.722c90.516,0,164.156-73.64,164.156-164.156V164.156 C551.033,73.64,477.393,0,386.878,0z M495.6,386.878c0,60.045-48.677,108.722-108.722,108.722H164.156 c-60.045,0-108.722-48.677-108.722-108.722V164.156c0-60.046,48.677-108.722,108.722-108.722h222.722 c60.045,0,108.722,48.676,108.722,108.722L495.6,386.878L495.6,386.878z"></path>
                            <linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="275.517" y1="4.57"
                                            x2="275.517" y2="549.72" gradientTransform="matrix(1 0 0 -1 0 554)">
                                <stop offset="0" style="stop-color:#E09B3D"></stop>
                                <stop offset="0.3" style="stop-color:#C74C4D"></stop>
                                <stop offset="0.6" style="stop-color:#C21975"></stop>
                                <stop offset="1" style="stop-color:#7024C4"></stop>
                            </linearGradient>
                            <path style="fill:url(#SVGID_2_);"
                                  d="M275.517,133C196.933,133,133,196.933,133,275.516s63.933,142.517,142.517,142.517 S418.034,354.1,418.034,275.516S354.101,133,275.517,133z M275.517,362.6c-48.095,0-87.083-38.988-87.083-87.083 s38.989-87.083,87.083-87.083c48.095,0,87.083,38.988,87.083,87.083C362.6,323.611,323.611,362.6,275.517,362.6z"></path>
                            <linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="418.31" y1="4.57"
                                            x2="418.31" y2="549.72" gradientTransform="matrix(1 0 0 -1 0 554)">
                                <stop offset="0" style="stop-color:#E09B3D"></stop>
                                <stop offset="0.3" style="stop-color:#C74C4D"></stop>
                                <stop offset="0.6" style="stop-color:#C21975"></stop>
                                <stop offset="1" style="stop-color:#7024C4"></stop>
                            </linearGradient>
                            <circle style="fill:url(#SVGID_3_);" cx="418.31" cy="134.07" r="34.15"></circle>
                        </g></svg>
                </a></li>


            <li><a href="https://twitter.com/BhavikKalal1" target="_blank">
                    <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 112.197 112.197"
                         style="enable-background:new 0 0 112.197 112.197;" xml:space="preserve"><g>
                            <circle style="fill:#55ACEE;" cx="56.099" cy="56.098" r="56.098"></circle>
                            <g>
                                <path style="fill:#F1F2F2;"
                                      d="M90.461,40.316c-2.404,1.066-4.99,1.787-7.702,2.109c2.769-1.659,4.894-4.284,5.897-7.417 c-2.591,1.537-5.462,2.652-8.515,3.253c-2.446-2.605-5.931-4.233-9.79-4.233c-7.404,0-13.409,6.005-13.409,13.409 c0,1.051,0.119,2.074,0.349,3.056c-11.144-0.559-21.025-5.897-27.639-14.012c-1.154,1.98-1.816,4.285-1.816,6.742 c0,4.651,2.369,8.757,5.965,11.161c-2.197-0.069-4.266-0.672-6.073-1.679c-0.001,0.057-0.001,0.114-0.001,0.17 c0,6.497,4.624,11.916,10.757,13.147c-1.124,0.308-2.311,0.471-3.532,0.471c-0.866,0-1.705-0.083-2.523-0.239 c1.706,5.326,6.657,9.203,12.526,9.312c-4.59,3.597-10.371,5.74-16.655,5.74c-1.08,0-2.15-0.063-3.197-0.188 c5.931,3.806,12.981,6.025,20.553,6.025c24.664,0,38.152-20.432,38.152-38.153c0-0.581-0.013-1.16-0.039-1.734 C86.391,45.366,88.664,43.005,90.461,40.316L90.461,40.316z"></path>
                            </g>
                        </g></svg>
                    </i> </a></li>


            <li><a href="https://www.facebook.com/bhavik.kalal17" target="_blank">
                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 408.788 408.788"
                         style="enable-background:new 0 0 408.788 408.788;width: 25px;" xml:space="preserve"><path
                                style="fill:#475993;"
                                d="M353.701,0H55.087C24.665,0,0.002,24.662,0.002,55.085v298.616c0,30.423,24.662,55.085,55.085,55.085 h147.275l0.251-146.078h-37.951c-4.932,0-8.935-3.988-8.954-8.92l-0.182-47.087c-0.019-4.959,3.996-8.989,8.955-8.989h37.882 v-45.498c0-52.8,32.247-81.55,79.348-81.55h38.65c4.945,0,8.955,4.009,8.955,8.955v39.704c0,4.944-4.007,8.952-8.95,8.955 l-23.719,0.011c-25.615,0-30.575,12.172-30.575,30.035v39.389h56.285c5.363,0,9.524,4.683,8.892,10.009l-5.581,47.087 c-0.534,4.506-4.355,7.901-8.892,7.901h-50.453l-0.251,146.078h87.631c30.422,0,55.084-24.662,55.084-55.084V55.085 C408.786,24.662,384.124,0,353.701,0z"></path></svg>
                </a></li>


        </ul>
        <p>


        </p>
        <p>Want to send me a letter? <a href="mailto:contact@bhavikkalal.com">Email me</a>.</p>
    </div>

</div>

<div class="footer">© 2017 <a style="font-size:11px!important;" href="https://bhavikkalal.com">Bhavik Kalal</a></div>

</body>
<script>

    $(document).keydown(function (event) {
        if (event.keyCode == 123) {
            console.log(" SORRY... Developer tool can't open this site");
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
            return false;
        }
    });
</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-124802214-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }

    gtag('js', new Date());

    gtag('config', 'UA-124802214-1');
</script>


<script src="particle.js"></script>

</html>
